This code is free to use under the GPL and was released by AddyOsmani.com.

You have complete rights to use the code and images in any way you see fit
as long as you do not pass the work on as your own nor sell it in the means
of a template or otherwise. The rights covered for use extend to personal
and business projects.

Thanks